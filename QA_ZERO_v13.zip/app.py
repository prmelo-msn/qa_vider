from flask import Flask
import transformers
from transformers import pipeline
from transformers import AutoTokenizer, AutoModelForQuestionAnswering
import os

# EB looks for an 'application' callable by default.
app = Flask(__name__)

context = r"""
A pandemia de COVID-19, também conhecida como pandemia de coronavírus, é uma pandemia em curso de COVID-19, 
uma doença respiratória aguda causada pelo coronavírus da síndrome respiratória aguda grave 2 (SARS-CoV-2). 
A doença foi identificada pela primeira vez em Wuhan, na província de Hubei, República Popular da China, 
em 1 de dezembro de 2019, mas o primeiro caso foi reportado em 31 de dezembro do mesmo ano. 
Acredita-se que o vírus tenha uma origem zoonótica, porque os primeiros casos confirmados 
tinham principalmente ligações ao Mercado Atacadista de Frutos do Mar de Huanan, que também vendia animais vivos. 
Em 11 de março de 2020, a Organização Mundial da Saúde declarou o surto uma pandemia. Até 8 de fevereiro de 2021, 
pelo menos 105 743 102 casos da doença foram confirmados em pelo menos 191 países e territórios, 
com cerca de 2 308 943 mortes e 58 851 440 pessoas curadas.
"""
diretorio1 = os.path.dirname(os.path.abspath("vocab.txt")) 
diretorio2 = os.path.dirname(os.path.abspath("config.json"))

@app.route("/")
def hello():
 retorno =  diretorio1 + '----' + diretorio2
 return retorno

@app.route("/qa")
def qa():
    model_name = 'pierreguillou/bert-large-cased-squad-v1.1-portuguese'

    tokenizer = AutoTokenizer.from_pretrained(diretorio1,local_files_only=True)
    model     = AutoModelForQuestionAnswering.from_pretrained(diretorio1, local_files_only=True)
    nlp       = pipeline("question-answering", model=model,tokenizer=tokenizer)

    question = "Quando começou a pandemia de Covid-19 no mundo?"

    result = nlp(question=question, context=context)   
    result = result['answer']     

    #result = "OK"
    return result 


# run the app.
if __name__ == "__main__":
    app.run()