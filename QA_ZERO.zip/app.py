from flask import Flask
import transformers
from transformers import pipeline
from transformers import AutoTokenizer, AutoModelForQuestionAnswering
import os
from flask import send_from_directory

# EB looks for an 'application' callable by default.
app = Flask(__name__)

context = "A pandemia de COVID-19, também conhecida como pandemia de coronavírus, é uma pandemia em curso de COVID-19, uma doença respiratória aguda causada pelo "
context += " coronavírus da síndrome respiratória aguda grave 2 (SARS-CoV-2). A doença foi identificada pela primeira vez em Wuhan, "
context += " na província de Hubei, República Popular da China, em 1 de dezembro de 2019, mas o primeiro caso foi reportado em 31 de dezembro do mesmo ano. "
context += " Acredita-se que o vírus tenha uma origem zoonótica, porque os primeiros casos confirmados tinham principalmente ligações ao Mercado Atacadista de Frutos do Mar de Huanan,"
context += " que também vendia animais vivos. Em 11 de março de 2020, a Organização Mundial da Saúde declarou o surto uma pandemia. Até 8 de fevereiro de 2021, "
context += " pelo menos 105 743 102 casos da doença foram confirmados em pelo menos 191 países e territórios, com cerca de 2 308 943 mortes e 58 851 440 pessoas curadas."

diretorio1 = os.path.dirname(os.path.abspath("vocab.txt")) 
diretorio2 = os.path.dirname(os.path.abspath("config.json"))
diretorio3 = os.path.dirname(os.path.abspath("pytorch_model.bin"))


@app.route("/")
def hello():
 retorno =  diretorio1 + '--zica--' + diretorio2 + '--zica--' + diretorio3
 return retorno

@app.route('/reports/<path:path>')
def send_report(path):
    return send_from_directory('reports', path)

@app.route("/qa")
def qa():
    model_name = 'pierreguillwou/bert-large-cased-squad-v1.1-portuguese'

    tokenizer = AutoTokenizer.from_pretrained('/var/app/current',local_files_only=True,cache_dir='/var/app/current')
    model     = AutoModelForQuestionAnswering.from_pretrained('/var/app/current',local_files_only=True,cache_dir='/var/app/current')
    nlp       = pipeline("question-answering", model=model,tokenizer=tokenizer)

    question = "Quando começou a pandemia de Covid-19 no mundo?"

    result = nlp(question=question, context=context)   
    result = result['answer']     

    #result = "OK"
    return result 

@app.route("/qa_pipeline")
def qa2():
    model_name = 'pierreguillou/bert-large-cased-squad-v1.1-portuguese'
    nlp = pipeline("question-answering", model=model_name)

    question = "Quando começou a pandemia de Covid-19 no mundo?"

    result = nlp(question=question, context=context)

    #print(f"Answer: '{result['answer']}', score: {round(result['score'], 4)}, start: {result['start']}, end: {result['end']}")       
    return result['answer']     


# run the app.
if __name__ == "__main__":
    app.run()